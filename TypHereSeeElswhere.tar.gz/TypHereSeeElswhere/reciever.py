import time
import sys
while True:
	filo=open("lock.txt","r+")
	stri=filo.read()
	stri=stri[:-1]
	sys.stdout.flush()
	#print([i for i in stri])
	if stri=="1":
		
		#print(time.asctime(time.localtime(time.time())))
		fileo=open("test.txt",'r')
		st=fileo.read()
		st=st[:-1]
		#print([i for i in st])
		#sys.stdout.write(st)
		#print("shit") 
		sys.stdout.flush()
		#print(st)
		print(st,end='')
		fileo.close()
		filo.seek(0)
		filo.write("0")
		#time.sleep(1)
	filo.close()
