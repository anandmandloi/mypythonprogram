#sender.sh
str="0"
echo $str > lock.txt
while true;
do
	value=`cat lock.txt`
	#echo $value
	if [ $value == "0" ] 
	then
	 	#date 
		read -n 1 p
		echo $p > test.txt
		str="1"
		#echo $str
		echo $str > lock.txt
		#echo here
	fi
done
